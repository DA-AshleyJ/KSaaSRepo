from flask import Flask, request, render_template
from ctypes import *
import os
import sys
import requests
import json

app = Flask(__name__)
ddkg_filename = ""
auth_id = ""
ks_protocol = "https"
ks_host = ""
ks_port = 443
verify_tls = False
device_name_alias_display = ""


class Logger:
    """
    Quick logging implementation to format output going to the console
    """

    def __init__(self):
        pass

    def err(self, msg):
        print(" [ERR ] %s" % msg)

    def info(self, msg):
        print(" [INFO] %s" % msg)


class Ddkg:
    log = Logger()

    def __init__(self, ddkg_path):
        self.ddkg_path = ddkg_path
        self.libc = None
        return

    def load_ddkg(self):
        # try loading the DDKG library
        try:
            self.libc = CDLL(self.ddkg_path)
            return True
        except OSError:
            return False

    def get_user_agent(self):
        user_agent_out = c_char_p()
        self.libc.naudaddk_getuseragentstring(byref(user_agent_out))
        user_agent = user_agent_out.value.strip()
        return "%s" % user_agent

    def get_device_key(self, challenge=None, role=None, provider=None):
        device_key_out = c_char_p()
        if challenge is None:
            # call the native DDKG function "getdevicekey" to get a generic ID key
            if provider is None:
                self.libc.naudaddk_getdevicekey(byref(device_key_out), None)
            else:
                self.libc.naudaddk_getdevicekeyoaep(provider.encode('utf-8'), byref(device_key_out), None)
        else:
            # pass in the challenge and role to get a device key
            self.libc.naudaddk_getdevicekeywithchallenge_withdevicerole(
                c_char_p(challenge.encode('utf-8')),
                c_char_p(role.encode('utf-8')),
                byref(device_key_out)
            )
        device_key = device_key_out.value.strip()
        self.libc.naudaddk_freedevicekey(byref(device_key_out))
        return device_key


class Http:
    log = Logger()

    def __init__(self, protocol, host, port, _user_agent):
        self.ks_url = ("%s://%s:%s/service-access-controller" % (protocol, host, port))
        self.user_agent = _user_agent
        return

    def post(self, endpoint, body, _verify_tls=True):
        url = self.ks_url + endpoint
        if _verify_tls is False:
            requests.packages.urllib3.disable_warnings()
        r = requests.post(
            url=url,
            data=body,
            headers={
                'Content-Type': 'application/json',
                "User-Agent": self.user_agent
            },
            verify=_verify_tls
        )
        return self.validate_response(r)

    def validate_response(self, r):
        log = Logger()
        # check for HTTP error status codes
        if r.ok:
            # load the response into a dictionary
            # log.info(r.text)
            json_resp = json.loads(r.text)

            # check if the KeyScaler statusCode is OK - this ensures that there were no errors at the application level
            if json_resp["statusCode"] != 0:
                log.err("KeyScaler returned error: %s" % (json_resp["message"]["errorMessage"]))
                index()
            else:
                return json_resp
        else:
            log.err("KeyScaler returned HTTP error code %s " % r.status_code)
            log.err("Exiting!")
            vin = "SBM16AEAXPW000192" # giving a working Vin to return to
            checkvin(vin[0:17])
        return checkvin(vin)


@app.route("/")
def index():
    vin = request.args.get('vin', '')
    return render_template('index.html', content=checkvin(vin))


@app.route("/<vin>")
def checkvin(vin):
    log = Logger()
    device_name_alias = vin
    dir_path = os.path.dirname(os.path.realpath(__file__))
    ddkg_file = (dir_path + ddkg_filename)
    ddkg = Ddkg(ddkg_file)
    if not ddkg.load_ddkg():
        sys.exit()
    user_agent = ddkg.get_user_agent()
    json_id_key = json.loads(ddkg.get_device_key())
    id_key = json_id_key["ddk"]
    ch_request = {
        "userAgent": user_agent,
        "challengeType": "auth",
        "userId": auth_id,
        "deviceKey": id_key
    }
    ch_request_body = json.dumps(ch_request)
    http = Http(ks_protocol, ks_host, ks_port, user_agent)
    ch_response = http.post("/challenge", ch_request_body, _verify_tls=verify_tls)
    auth_challenge = ch_response["message"]["challenge"]
    json_auth_key = json.loads(ddkg.get_device_key(auth_challenge, "DA Agent"))
    auth_key = json_auth_key["ddk"]
    gen_request = {
        "auth": {
            "userId": auth_id,
            "deviceKey": auth_key,
        },
        "deviceNameAlias": device_name_alias,
        "deviceNameAliasDisplay": device_name_alias_display
    }
    auth_request_body = json.dumps(gen_request, indent=4)
    auth_response_search = http.post("/devices/search", auth_request_body, _verify_tls=verify_tls)
    json_output1 = json.dumps(auth_response_search, indent=4, sort_keys=True)
    resp = json.loads(json_output1)
    status = str(resp['message']['devices'][0]['certificateStatus'])
    status2 = str(resp['message']['devices'][0]['deviceNameAlias'])
    return ("VIN Number: " + status2 + " Status: " + status)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8080, debug=True)
